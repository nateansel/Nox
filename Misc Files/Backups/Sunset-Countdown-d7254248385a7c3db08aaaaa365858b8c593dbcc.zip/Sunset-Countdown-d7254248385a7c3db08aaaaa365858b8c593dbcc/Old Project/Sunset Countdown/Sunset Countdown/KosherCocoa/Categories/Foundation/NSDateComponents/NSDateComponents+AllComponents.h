//
//  NSDateComponents+AllComponents.h
//  MBCalendarKit
//
//  Created by Moshe Berman on 4/12/13.
//  Copyright (c) 2013 Moshe Berman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateComponents (AllComponents)

+ (NSUInteger)allComponents;

@end
