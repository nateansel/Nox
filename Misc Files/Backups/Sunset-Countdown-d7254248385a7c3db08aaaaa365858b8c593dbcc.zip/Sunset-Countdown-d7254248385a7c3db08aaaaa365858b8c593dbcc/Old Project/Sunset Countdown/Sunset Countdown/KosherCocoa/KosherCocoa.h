/**
 *  KosherCocoa.h
 *  KosherCocoa 2
 *
 *  Created by Moshe Berman on 8/17/13.
 *  Updated by Moshe Berman on 10/11/13.
 *
 *  Use of KosherCocoa 2 is governed by the LGPL 2.1 License.
 */

#ifndef KosherCocoa_KosherCocoa_h
#define KosherCocoa_KosherCocoa_h

#import "Solar.h"
#import "Calendar.h"

#endif
